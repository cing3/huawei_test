import sys
import numpy as np


EPS = 1e-9


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _segment_proper_intersect(a1, a2, b1, b2, eps=EPS):
    da = a2 - a1
    db = b2 - b1
    c1 = _cross(da, b1 - a1)
    c2 = _cross(da, b2 - a1)
    c3 = _cross(db, a1 - b1)
    c4 = _cross(db, a2 - b1)
    return (c1 * c2 < -eps) and (c3 * c4 < -eps)


def _point_on_segment_strict_or_boundary(p, a, b, eps=EPS):
    ab = b - a
    ap = p - a
    if abs(_cross(ab, ap)) > eps:
        return False
    dot = np.dot(ap, ab)
    if dot < -eps:
        return False
    if dot - np.dot(ab, ab) > eps:
        return False
    return True


def _point_in_polygon_strict(p, poly, eps=EPS):
    n = len(poly)
    # 边界点不视为“重叠内部”
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        if _point_on_segment_strict_or_boundary(p, a, b, eps):
            return False

    inside = False
    x, y = p
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        ay, by = a[1], b[1]

        cond = (ay > y) != (by > y)
        if cond:
            t = (y - ay) / (by - ay)
            x_int = a[0] + t * (b[0] - a[0])
            if x_int > x + eps:
                inside = not inside
    return inside


def _bbox_overlap(poly_a, poly_b, eps=EPS):
    min_a = np.min(poly_a, axis=0)
    max_a = np.max(poly_a, axis=0)
    min_b = np.min(poly_b, axis=0)
    max_b = np.max(poly_b, axis=0)
    if max_a[0] < min_b[0] - eps or max_b[0] < min_a[0] - eps:
        return False
    if max_a[1] < min_b[1] - eps or max_b[1] < min_a[1] - eps:
        return False
    return True


def _polygons_overlap_strict(poly_a, poly_b, eps=EPS):
    # 先做包围盒快速排斥
    if not _bbox_overlap(poly_a, poly_b, eps):
        return False

    na = len(poly_a)
    nb = len(poly_b)

    # 1) 边与边的“真交” => 必有面积重叠
    for i in range(na):
        a1 = poly_a[i]
        a2 = poly_a[(i + 1) % na]
        for j in range(nb):
            b1 = poly_b[j]
            b2 = poly_b[(j + 1) % nb]
            if _segment_proper_intersect(a1, a2, b1, b2, eps):
                return True

    # 2) 顶点严格包含（任一顶点）
    for p in poly_a:
        if _point_in_polygon_strict(p, poly_b, eps):
            return True
    for p in poly_b:
        if _point_in_polygon_strict(p, poly_a, eps):
            return True

    # 3) 如果没有真交且没有严格包含，则仅接触或分离，均视为“无重叠”
    return False


def _collect_candidate_dirs(poly_a, poly_b, eps=EPS):
    dirs = []

    def add_dirs_from_poly(poly):
        m = len(poly)
        for i in range(m):
            e = poly[(i + 1) % m] - poly[i]
            norm = np.hypot(e[0], e[1])
            if norm <= eps:
                continue
            n = np.array([-e[1], e[0]], dtype=np.float64) / norm
            dirs.append(n)
            dirs.append(-n)

    add_dirs_from_poly(poly_a)
    add_dirs_from_poly(poly_b)

    # 去重（方向近似）
    uniq = []
    for d in dirs:
        keep = True
        for u in uniq:
            if abs(np.dot(d, u) - 1.0) < 1e-10:
                keep = False
                break
        if keep:
            uniq.append(d)

    # 退化保护：如果方向集为空，给两个标准方向
    if not uniq:
        uniq = [np.array([1.0, 0.0]), np.array([0.0, 1.0])]
    return uniq


def _estimate_initial_high(poly_a, poly_b, d):
    # 基于投影跨度的保守上界估计
    pa = poly_a @ d
    pb = poly_b @ d
    span_a = np.max(pa) - np.min(pa)
    span_b = np.max(pb) - np.min(pb)
    return max(1.0, span_a + span_b + 1.0)


def _find_exit_distance_along_dir(poly_a, moved_b, d, eps=EPS):
    # 已知 t=0 重叠，找最小 t>=0 使得不再重叠
    def overlap_at(t):
        return _polygons_overlap_strict(poly_a, moved_b + t * d, eps)

    low = 0.0
    high = _estimate_initial_high(poly_a, moved_b, d)

    # 指数扩张上界直到分离
    for _ in range(40):
        if not overlap_at(high):
            break
        high *= 2.0
    else:
        return np.inf

    # 二分精化
    for _ in range(55):
        mid = 0.5 * (low + high)
        if overlap_at(mid):
            low = mid
        else:
            high = mid

    return high


def calculate_mtv(poly_a, poly_b, translation):
    # 这一步是将多边形B按照平移向量移动到新的位置
    moved_b = poly_b + np.array(translation, dtype=np.float64)

    # 无重叠则直接返回零向量
    if not _polygons_overlap_strict(poly_a, moved_b):
        return 0.0, 0.0

    # 候选方向：两多边形边法向（含正反）
    dirs = _collect_candidate_dirs(poly_a, moved_b)

    best_dist = np.inf
    best_vec = np.array([0.0, 0.0], dtype=np.float64)

    for d in dirs:
        t = _find_exit_distance_along_dir(poly_a, moved_b, d)
        if not np.isfinite(t):
            continue
        if t < best_dist:
            best_dist = t
            best_vec = t * d

    # 兜底（理论上不应触发）：若未找到可行方向，返回0
    if not np.isfinite(best_dist):
        return 0.0, 0.0

    return float(best_vec[0]), float(best_vec[1])


def main():
    # 读取多边形A和B的顶点数
    line1 = sys.stdin.readline().strip()
    if not line1:
        return
    na, nb = map(int, line1.split())

    # 读取多边形的坐标点
    coords_a_raw = list(map(float, sys.stdin.readline().split()))
    coords_b_raw = list(map(float, sys.stdin.readline().split()))

    poly_a = np.array(coords_a_raw, dtype=np.float64).reshape(-1, 2)
    poly_b = np.array(coords_b_raw, dtype=np.float64).reshape(-1, 2)

    # 读取预处理就绪信号
    sys.stdin.readline().strip()

    # 告诉判题器：预处理完成
    print("OK")
    sys.stdout.flush()

    # 读取测试点的数量
    line_k = sys.stdin.readline().strip()
    if not line_k:
        return
    k = int(line_k)

    # 读取所有的平移测试向量
    translations = []
    for _ in range(k):
        tx, ty = map(float, sys.stdin.readline().split())
        translations.append((tx, ty))

    # 读取数据发送完毕的OK信号
    sys.stdin.readline().strip()

    # 开始计算结果
    results = []
    for t in translations:
        mtv_x, mtv_y = calculate_mtv(poly_a, poly_b, t)
        results.append((mtv_x, mtv_y))

    # 输出结果
    print(k)
    for rx, ry in results:
        print(f"{rx:.5f} {ry:.5f}")

    print("OK")
    sys.stdout.flush()


if __name__ == "__main__":
    main()